import rclpy
from rclpy.node import Node

from sensor_msgs.msg import LaserScan        # CHANGED THE MESSAGE TYPE

class ScanSubscriber(Node):                  # CHANGED THE CLASS NAME

    def __init__(self):
        super().__init__('scan_subscriber')  # CHANGED THE NODE NAME
        self.subscription = self.create_subscription(
            LaserScan,                       # CHANGED THE MESSAGE TYPE
            '/scan',                         # CHANGED THE TOPIC NAME
            self.listener_callback,
            10)
        self.subscription  # prevent unused variable warning
        print("Init End")

    def listener_callback(self, msg):
        self.get_logger().info('Called')
#        self.get_logger().info('The distance of ahead: "%f"' % msg.ranges[10])
        if msg.ranges[10] > 2.0:
          print("Far")
        else:
          print("Near")



def main(args=None):
    rclpy.init(args=args)

    minimal_subscriber = ScanSubscriber()      # CHANGED THE CLASSNAME

    rclpy.spin(minimal_subscriber)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    minimal_subscriber.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
